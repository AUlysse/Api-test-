// Function to hide the loader
function hideloader() {
    document.getElementById('loading').style.display = 'none';
}

// Function to define innerHTML for HTML table
function show(data) {
    let tab = 
        `<tr>
          <th>Name</th>
          <th>Birth year</th>
          <th>Eye Color</th>
          <th>Height</th>
         </tr>`;

          // Loop to access all rows 
    for (let r of data) {
        tab += `<tr> 
    <td>${r.name} </td>
    <td>${r.birth_year}</td>
    <td>${r.eye_color}</td> 
    <td>${r.height}</td>          
</tr>`;
    }
// Setting innerHTML as tab variable
document.getElementById("name").innerHTML = tab;
}

// from API doc https://swapi.dev/
async function stars() {
    const apiUrl = 'https://swapi.dev/api/people/?format=json'

     // Storing response
    const response = await fetch(apiUrl);

    // Storing data in form of JSON
    let data = await response.json();
        if (response) {
            hideloader();
            //console.log(data.results[0])
    }
    console.log(data.results);
    show(data.results);
}   



stars()